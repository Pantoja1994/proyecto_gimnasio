// controllers/cursoController.js
const db = require('../config/db');
const path = require('path');
const fs = require('fs');

// Crear un curso y guardar la imagen
const crearCurso = (req, res) => {
    console.log('req.body:', req.body);
    console.log('req.files:', req.files);

    const { nombre, descripcion, costo, duracion } = req.body;
    let imagen_url = null;

    // Verificar si se subió una imagen
    if (req.files && req.files.imagen) {
        const imagen = req.files.imagen;
        const uploadPath = path.join(__dirname, '..', 'public', 'images', imagen.name);

        imagen.mv(uploadPath, (err) => {
            if (err) {
                console.error('Error al guardar la imagen:', err);
                return res.status(500).json({ error: 'Error al subir la imagen' });
            }
        });
        imagen_url = `/images/${imagen.name}`;
    }

    const query = 'INSERT INTO cursos (nombre, descripcion, costo, duracion, imagen_url) VALUES (?, ?, ?, ?, ?)';
    db.query(query, [nombre, descripcion, costo, duracion, imagen_url], (err) => {
        if (err) {
            console.error('Error al crear el curso:', err);
            return res.status(500).json({ error: 'Error al crear el curso' });
        }
        res.status(200).json({ message: 'Curso creado exitosamente' });
    });
};


// Obtener todos los cursos
const obtenerCursos = (req, res) => {
    const query = 'SELECT * FROM cursos';
    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: 'Error al obtener los cursos' });
        res.status(200).json(results);
    });
};

// Registrar en un curso
const registrarEnCurso = (req, res) => {
    const { curso_id, nombre_persona, telefono } = req.body;
    const query = 'INSERT INTO inscripciones_cursos (curso_id, nombre_persona, telefono) VALUES (?, ?, ?)';
    db.query(query, [curso_id, nombre_persona, telefono], (err) => {
        if (err) return res.status(500).json({ error: 'Error al registrar en el curso' });
        res.status(200).json({ message: 'Registrado exitosamente en el curso' });
    });
};

// Obtener inscripciones de un curso
const obtenerInscripcionesPorCurso = (req, res) => {
    const { curso_id } = req.params;
    const query = 'SELECT * FROM inscripciones_cursos WHERE curso_id = ?';
    db.query(query, [curso_id], (err, results) => {
        if (err) return res.status(500).json({ error: 'Error al obtener inscripciones' });
        res.status(200).json(results);
    });
};

module.exports = {
    crearCurso,
    obtenerCursos,
    registrarEnCurso,
    obtenerInscripcionesPorCurso
};
