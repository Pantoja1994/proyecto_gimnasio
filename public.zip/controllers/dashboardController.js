const db = require('../config/db');
const path = require('path');
const fs = require('fs');
const multer = require('multer');

// Configuración de almacenamiento con multer
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'public/uploads'); // Carpeta de destino para las fotos
    },
    filename: (req, file, cb) => {
        const userId = req.params.userId;
        const fileType = file.fieldname === 'fotoAntes' ? 'fotoAntes' : 'fotoDespues';
        cb(null, `${fileType}-${userId}${path.extname(file.originalname)}`);
    }
});

const upload = multer({ storage: storage });

// Obtener todos los usuarios para el dashboard
const getUsers = (req, res) => {
    db.query('SELECT * FROM usuarios', (error, results) => {
        if (error) {
            console.error("Error obteniendo usuarios:", error);
            res.status(500).json({ error: 'Error obteniendo usuarios' });
        } else {
            res.json(results);
        }
    });
};

// Obtener todos los usuarios para mostrarlos en cards con sus fotos
const getUsersForCards = (req, res) => {
    const query = `
        SELECT usuarios.id, usuarios.nombre, usuarios.edad, usuarios.genero, usuarios.peso, usuarios.altura,
               usuarios.objetivo, usuarios.telefono, usuarios.retoSeleccionado,
               fotos.foto_antes, fotos.foto_despues
        FROM usuarios
        LEFT JOIN fotos ON usuarios.id = fotos.user_id
    `;
    db.query(query, (error, results) => {
        if (error) {
            console.error("Error obteniendo usuarios para cards:", error);
            res.status(500).json({ error: 'Error obteniendo usuarios para cards' });
        } else {
            res.json(results);
        }
    });
};

// Subir fotos del usuario (antes y después)
const uploadPhoto = (req, res) => {
    const userId = req.params.userId;
    if (!req.files || (!req.files.fotoAntes && !req.files.fotoDespues)) {
        return res.status(400).json({ error: 'No se proporcionaron fotos para subir' });
    }

    // Manejo de la foto del antes
    if (req.files.fotoAntes) {
        const fotoAntesPath = path.join(__dirname, '..', 'public', 'uploads', `fotoAntes_${userId}.jpg`);
        req.files.fotoAntes.mv(fotoAntesPath, (err) => {
            if (err) {
                console.error('Error al subir la foto del antes:', err);
                return res.status(500).json({ error: 'Error al subir la foto del antes' });
            }
        });
    }

    // Manejo de la foto del después
    if (req.files.fotoDespues) {
        const fotoDespuesPath = path.join(__dirname, '..', 'public', 'uploads', `fotoDespues_${userId}.jpg`);
        req.files.fotoDespues.mv(fotoDespuesPath, (err) => {
            if (err) {
                console.error('Error al subir la foto del después:', err);
                return res.status(500).json({ error: 'Error al subir la foto del después' });
            }
        });
    }

    res.json({ message: 'Fotos subidas exitosamente' });
};


// Eliminar usuario
const deleteUser = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM usuarios WHERE id=?', [id], (err, result) => {
        if (err) {
            console.error('Error al eliminar usuario:', err);
            res.status(500).json({ error: 'Error al eliminar usuario' });
        } else {
            res.json({ message: 'Usuario eliminado correctamente' });
        }
    });
};

// Exportar todas las funciones
module.exports = {
    getUsers,
    getUsersForCards,
    uploadPhoto,
    deleteUser
};
