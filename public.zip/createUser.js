const bcrypt = require('bcrypt');
const db = require('./config/db');
//Variables para crear sesiones
const username = 'admin';
const plainPassword = '1234';
const nombreCompleto = 'Alexis Ponce';

bcrypt.hash(plainPassword, 10, (err, hash) => {
  if (err) throw err;

  const sql = 'INSERT INTO users (username, password, nombre_completo) VALUES (?, ?, ?)';
  db.query(sql, [username, hash, nombreCompleto], (err, result) => {
    if (err) throw err;
    console.log('Usuario insertado correctamente');
    process.exit();
  });
});
