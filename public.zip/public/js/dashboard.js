// Cargar los usuarios al cargar la página
document.addEventListener('DOMContentLoaded', () => {
    fetch('/api/users/dashboard/users') // Llama a la ruta del servidor
        .then(response => response.json())
        .then(data => {
            const userTableBody = document.getElementById('user-table-body');
            data.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.id}</td>
                    <td>${user.nombre}</td>
                    <td>${user.edad}</td>
                    <td>${user.genero}</td>
                    <td>${user.peso}</td>
                    <td>${user.altura}</td>
                    <td>${user.diasActividad}</td>
                    <td>${user.tipoActividad}</td>
                    <td>${user.objetivo}</td>
                    <td>${user.telefono}</td>
                    <td>${user.retoSeleccionado || 'N/A'}</td>
                    <td>
                        <button class="btn btn-sm btn-danger" onclick="eliminarUsuario(${user.id})">Eliminar</button>
                    </td>
                `;
                userTableBody.appendChild(row);
            });
        })
        .catch(error => console.error('Error al cargar los usuarios:', error));
});

// Obtener el token y mostrar el mensaje de bienvenida
document.addEventListener('DOMContentLoaded', () => {
    const token = document.cookie.split('; ').find(row => row.startsWith('token=')).split('=')[1];
    const decoded = jwt_decode(token);

    const welcomeMessage = document.getElementById('user-name');
    welcomeMessage.textContent = `Bienvenido, ${decoded.nombre_completo}`;

    // Cargar los usuarios en cards
    cargarUsuariosEnCards();
});

// Función para eliminar un usuario
function eliminarUsuario(id) {
    if (!confirm('¿Estás seguro de que deseas eliminar este usuario?')) return;

    fetch(`/api/users/${id}`, {
        method: 'DELETE'
    })
    .then(response => response.json())
    .then(result => {
        alert(result.message);
        location.reload(); // Recarga la página para actualizar la lista de usuarios
    })
    .catch(error => console.error('Error al eliminar usuario:', error));
}

// Mostrar y cargar fotos en cards
function cargarUsuariosEnCards() {
    fetch('/api/users/cards') // Ruta para obtener datos de los usuarios en formato card
        .then(response => response.json())
        .then(data => {
            const container = document.getElementById('cards-container');
            container.innerHTML = ''; // Limpia el contenedor para refrescar las cards

            data.forEach(user => {
                const timestamp = new Date().getTime(); // Evita el caché de la imagen

                const card = document.createElement('div');
                card.classList.add('card', 'mb-4', 'shadow');

                card.innerHTML = `
                    <div class="photo-container">
                        <img src="${user.foto_antes ? `${user.foto_antes}?t=${timestamp}` : 'images/placeholder.jpg'}" 
                             alt="Foto Antes" class="user-photo" 
                             onclick="showModal('${user.foto_antes ? `${user.foto_antes}?t=${timestamp}` : 'images/placeholder.jpg'}', 'Foto Antes')">
                        <img src="${user.foto_despues ? `${user.foto_despues}?t=${timestamp}` : 'images/placeholder.jpg'}" 
                             alt="Foto Después" class="user-photo" 
                             onclick="showModal('${user.foto_despues ? `${user.foto_despues}?t=${timestamp}` : 'images/placeholder.jpg'}', 'Foto Después')">
                    </div>
                    <div class="card-body">
                        <p><strong>Nombre:</strong> ${user.nombre}</p>
                        <p><strong>Edad:</strong> ${user.edad}</p>
                        <p><strong>Género:</strong> ${user.genero}</p>
                        <p><strong>Peso:</strong> ${user.peso} kg</p>
                        <p><strong>Altura:</strong> ${user.altura} cm</p>
                        <p><strong>Objetivo:</strong> ${user.objetivo}</p>
                        <p><strong>Reto Seleccionado:</strong> ${user.retoSeleccionado}</p>
                        <p class="upload-text" onclick="mostrarCamposSubida(${user.id})">Subir fotos</p>
                        <div id="upload-fields-${user.id}" class="upload-fields" style="display: none;">
                            <label for="fotoAntes-${user.id}">Foto del Antes</label>
                            <input type="file" accept="image/*" class="upload-button" id="fotoAntes-${user.id}">
                            
                            <label for="fotoDespues-${user.id}">Foto del Después</label>
                            <input type="file" accept="image/*" class="upload-button" id="fotoDespues-${user.id}">
                            
                            <div class="button-group">
                                <button class="upload-confirm" onclick="subirFotos(${user.id})">Guardar Fotos</button>
                                <button class="cancel-upload" onclick="cancelarSubida(${user.id})">Cancelar</button>
                            </div>
                        </div>
                    </div>
                `;
                
                container.appendChild(card);
            });
        })
        .catch(error => console.error('Error al cargar los usuarios:', error));
}



function previsualizarFoto(userId, tipo) {
    const input = document.getElementById(`foto${tipo === 'antes' ? 'Antes' : 'Despues'}-${userId}`);
    const file = input.files[0];
    const reader = new FileReader();

    reader.onload = function(e) {
        const imgElement = document.querySelector(`#upload-fields-${userId} .user-photo.${tipo}`);
        imgElement.src = e.target.result;
    };

    if (file) {
        reader.readAsDataURL(file);
    }
}

function mostrarCamposSubida(userId) {
    const uploadFields = document.getElementById(`upload-fields-${userId}`);
    uploadFields.style.display = uploadFields.style.display === 'none' ? 'block' : 'none';
}
//hASTA AQI JALA: 1234
function subirFotos(userId) {
    const fotoAntesInput = document.getElementById(`fotoAntes-${userId}`);
    const fotoDespuesInput = document.getElementById(`fotoDespues-${userId}`);
    const fotoAntesFile = fotoAntesInput.files[0];
    const fotoDespuesFile = fotoDespuesInput.files[0];

    const formData = new FormData();
    if (fotoAntesFile) formData.append('fotoAntes', fotoAntesFile);
    if (fotoDespuesFile) formData.append('fotoDespues', fotoDespuesFile);

    fetch(`/api/users/${userId}/upload`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(result => {
        if (result.message) {
            alert(result.message);
            cargarUsuariosEnCards(); // Recarga las cards después de subir las fotos
        } else if (result.error) {
            alert(result.error);
        }
    })
    .catch(error => console.error('Error al subir las fotos:', error));
}

function showModal(imageSrc, altText) {
    const modal = document.getElementById("imageModal");
    const modalImg = document.getElementById("modalImage");
    const captionText = document.getElementById("caption");

    modal.style.display = "block";
    modalImg.src = imageSrc;
    captionText.innerHTML = altText;
}

function closeModal() {
    const modal = document.getElementById("imageModal");
    modal.style.display = "none";
}

function cancelarSubida(userId) {
    // Oculta los campos de carga de fotos
    const uploadFields = document.getElementById(`upload-fields-${userId}`);
    if (uploadFields) {
        uploadFields.style.display = 'none';
    }

    // Limpia los archivos seleccionados en los campos de carga
    const fotoAntesInput = document.getElementById(`fotoAntes-${userId}`);
    const fotoDespuesInput = document.getElementById(`fotoDespues-${userId}`);
    
    if (fotoAntesInput) {
        fotoAntesInput.value = '';
    }
    if (fotoDespuesInput) {
        fotoDespuesInput.value = '';
    }
}
//Curso nuevo 
document.getElementById('form-curso-nuevo').addEventListener('submit', async (e) => {
    e.preventDefault();
    const formData = new FormData(e.target);

    try {
        const response = await fetch('/api/cursos/crear', {
            method: 'POST',
            body: formData
        });
        const result = await response.json();
        alert(result.message || 'Curso creado exitosamente');
        cargarCursosDashboard();
        cancelarFormularioCurso();
    } catch (error) {
        console.error('Error al crear curso:', error);
    }
});


async function cargarCursosDashboard() {
    try {
        const response = await fetch('/api/cursos/obtener');
        const cursos = await response.json();

        const cursosContainer = document.getElementById('cursos-cards-container');
        cursosContainer.innerHTML = ''; // Limpia el contenedor antes de llenarlo

        cursos.forEach(curso => {
            const cursoCard = document.createElement('div');
            cursoCard.classList.add('col-md-4', 'mb-4');
            cursoCard.innerHTML = `
                <div class="card h-100 shadow">
                    <img src="${curso.imagen_url || '/images/default.jpg'}" class="card-img-top" alt="${curso.nombre}">
                    <div class="card-body">
                        <h5 class="card-title">${curso.nombre}</h5>
                        <p class="card-text">${curso.descripcion}</p>
                        <p><strong>Costo:</strong> $${curso.costo}</p>
                        <p><strong>Duración:</strong> ${curso.duracion}</p>
                        <button class="btn btn-info btn-sm" onclick="verInscripciones(${curso.id})">Ver Inscripciones</button>
                        <button class="btn btn-warning btn-sm" onclick="editarCurso(${curso.id})">Editar</button>
                        <button class="btn btn-danger btn-sm" onclick="eliminarCurso(${curso.id})">Eliminar</button>
                    </div>
                </div>
            `;
            cursosContainer.appendChild(cursoCard);
        });
    } catch (error) {
        console.error('Error al cargar cursos:', error);
    }
}

async function verInscripciones(cursoId) {
    try {
        const response = await fetch(`/api/cursos/inscripciones/${cursoId}`);
        const inscripciones = await response.json();
        alert(`Inscripciones para el curso: \n` + inscripciones.map(i => `${i.nombre_persona} - ${i.telefono}`).join('\n'));
    } catch (error) {
        console.error('Error al cargar inscripciones:', error);
    }
}
