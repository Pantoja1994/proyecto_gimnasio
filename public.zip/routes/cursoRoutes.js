// routes/cursoRoutes.js
const express = require('express');
const router = express.Router();
const { crearCurso, obtenerCursos, registrarEnCurso, obtenerInscripcionesPorCurso } = require('../controllers/cursoController');

// Ruta para crear un curso
router.post('/crear', crearCurso);

// Ruta para obtener todos los cursos
router.get('/obtener', obtenerCursos);

// Ruta para registrar un usuario en un curso
router.post('/registrar', registrarEnCurso);

// Ruta para obtener inscripciones de un curso específico
router.get('/inscripciones/:curso_id', obtenerInscripcionesPorCurso);

module.exports = router;
