// routes/estadisticasRoutes.js
const express = require('express');
const router = express.Router();
const db = require('../config/db');

// Endpoint para filtrar estadísticas
router.post('/filtrar', (req, res) => {
    const { tipoReto, edadMinima, edadMaxima, genero } = req.body;

    console.log("Datos recibidos en el backend:", { tipoReto, edadMinima, edadMaxima, genero });

    // Construir la consulta SQL basada en los filtros
    let query = 'SELECT COUNT(*) AS total, curso_id FROM inscripciones_cursos WHERE 1=1';
    if (tipoReto) query += ` AND curso_id = ${db.escape(tipoReto)}`;
    if (edadMinima) query += ` AND edad >= ${db.escape(edadMinima)}`;
    if (edadMaxima) query += ` AND edad <= ${db.escape(edadMaxima)}`;
    if (genero) query += ` AND genero = ${db.escape(genero)}`;
    query += ' GROUP BY curso_id';

    console.log("Query ejecutada:", query);

    db.query(query, (error, results) => {
        if (error) {
            console.error('Error al obtener estadísticas:', error);
            return res.status(500).json({ error: 'Error al obtener estadísticas' });
        }
        console.log("Resultados obtenidos:", results);
        res.json(results);
    });
});


module.exports = router;
