require('dotenv').config();
const express = require('express');
const userRoutes = require('./routes/userRoutes');
const path = require('path');
const app = express();

// Configuración de middlewares
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public')); // Sirve archivos estáticos desde la carpeta 'public'

// Rutas de usuario y dashboard
app.use('/api/users', userRoutes);
app.use('/dashboard', userRoutes);

// Ruta principal para servir el archivo HTML principal
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, '/views/index.html'));
});

// Puerto y escucha del servidor
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
    console.log(`Servidor corriendo en el puerto ${PORT}`);
});
