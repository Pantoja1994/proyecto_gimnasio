// authController.js
const db = require('../config/db');
const jwt = require('jsonwebtoken');

const loginUser = (req, res) => {
    const { username, password } = req.body; // Cambié email a username

    const query = `SELECT * FROM users WHERE username = ?`;
    db.query(query, [username], (err, results) => {
        if (err) return res.status(500).json({ error: 'Error al iniciar sesión' });
        if (results.length === 0) return res.status(401).json({ error: 'Usuario no encontrado' });

        const user = results[0];

        if (password !== user.password) { // Verifica la contraseña
            return res.status(401).json({ error: 'Contraseña incorrecta' });
        }

        // Genera el token
        const token = jwt.sign({ id: user.id }, process.env.JWT_SECRET, { expiresIn: '1h' });

        return res.status(200).json({ message: 'Login exitoso', token });
    });
};

module.exports = { loginUser };
