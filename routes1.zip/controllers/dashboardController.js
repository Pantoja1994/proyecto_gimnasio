const db = require('../config/db');
const path = require('path');
const fs = require('fs');

// Obtener todos los usuarios para el dashboard
exports.getUsers = (req, res) => {
    db.query('SELECT * FROM usuarios', (error, results) => {
        if (error) {
            console.error("Error obteniendo usuarios:", error);
            res.status(500).json({ error: 'Error obteniendo usuarios' });
        } else {
            res.json(results);
        }
    });
};

// Actualizar usuario (incluye reto pagado)
exports.updateUser = (req, res) => {
    const { id } = req.params;
    const { nombre, edad, genero, peso, altura, diasActividad, tipoActividad, objetivo, telefono, reto, reto_pagado } = req.body;

    db.query(
        'UPDATE usuarios SET nombre=?, edad=?, genero=?, peso=?, altura=?, diasActividad=?, tipoActividad=?, objetivo=?, telefono=?, reto=?, reto_pagado=? WHERE id=?',
        [nombre, edad, genero, peso, altura, diasActividad, tipoActividad, objetivo, telefono, reto, reto_pagado, id],
        (err, result) => {
            if (err) {
                console.error('Error al actualizar el usuario:', err);
                res.status(500).json({ error: 'Error al actualizar usuario' });
            } else {
                res.json({ message: 'Usuario actualizado correctamente' });
            }
        }
    );
};

// Subir fotos de antes y después
exports.uploadPhotos = (req, res) => {
    const { id } = req.params;
    const fotoAntes = req.files?.fotoAntes;
    const fotoDespues = req.files?.fotoDespues;

    if (!fotoAntes || !fotoDespues) {
        return res.status(400).json({ error: 'Se requieren ambas fotos' });
    }

    const uploadDir = path.join(__dirname, '../public/uploads');
    if (!fs.existsSync(uploadDir)) fs.mkdirSync(uploadDir);

    const fotoAntesPath = path.join(uploadDir, `${id}_antes.jpg`);
    const fotoDespuesPath = path.join(uploadDir, `${id}_despues.jpg`);

    fotoAntes.mv(fotoAntesPath, (err) => {
        if (err) return res.status(500).json({ error: 'Error al subir foto de antes' });
        fotoDespues.mv(fotoDespuesPath, (err) => {
            if (err) return res.status(500).json({ error: 'Error al subir foto de después' });

            db.query(
                'UPDATE usuarios SET foto_antes=?, foto_despues=? WHERE id=?',
                [`/uploads/${id}_antes.jpg`, `/uploads/${id}_despues.jpg`, id],
                (err, result) => {
                    if (err) {
                        console.error('Error al guardar rutas de fotos:', err);
                        return res.status(500).json({ error: 'Error al guardar fotos' });
                    }
                    res.json({ message: 'Fotos subidas correctamente' });
                }
            );
        });
    });
};

// Eliminar usuario
exports.deleteUser = (req, res) => {
    const { id } = req.params;
    db.query('DELETE FROM usuarios WHERE id=?', [id], (err, result) => {
        if (err) {
            console.error('Error al eliminar usuario:', err);
            res.status(500).json({ error: 'Error al eliminar usuario' });
        } else {
            res.json({ message: 'Usuario eliminado correctamente' });
        }
    });
};
