const db = require('../config/db');
const { sendWhatsAppMessage } = require('../utils/whatsappAPI');

const isValidPhoneNumber = (phone) => {
    const phoneRegex = /^\+?\d{10,15}$/; // Expresión regular para validar el formato de número
    return phoneRegex.test(phone);
};

const registerUser = (req, res) => {
    const { nombre, edad, genero, peso, altura, diasActividad, tipoActividad, objetivo, telefono, retoSeleccionado } = req.body;

    // Validar el número de teléfono
    if (!isValidPhoneNumber(telefono)) {
        return res.status(400).json({ error: 'Número de teléfono no es válido. Debe ser en formato internacional.' });
    }

    // Guardar datos en la base de datos
    const query = `INSERT INTO usuarios (nombre, edad, genero, peso, altura, diasActividad, tipoActividad, objetivo, telefono, retoSeleccionado) 
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
    
    db.query(query, [nombre, edad, genero, peso, altura, diasActividad, tipoActividad, objetivo, telefono, retoSeleccionado], (err, result) => {
        if (err) return res.status(500).json({ error: 'Error al registrar al usuario' });

        // Enviar mensaje por WhatsApp
        const message = `¡Hola ${nombre}! Bienvenido al reto. Un especialista se pondrá en contacto en 1-2 días.`;
        sendWhatsAppMessage(telefono, message);
        
        res.status(200).json({ message: 'Usuario registrado y mensaje enviado' });
    });
};

const getUsersDashboard = (req, res) => {
    const query = 'SELECT * FROM usuarios';

    db.query(query, (err, results) => {
        if (err) return res.status(500).json({ error: 'Error al obtener los usuarios' });

        res.status(200).json(results);
    });
};

module.exports = { registerUser, getUsersDashboard }; 

