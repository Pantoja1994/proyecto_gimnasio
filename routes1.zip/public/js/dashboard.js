// Cargar usuarios al iniciar la página
window.onload = function() {
    loadUsers();
};

// Función para cargar usuarios y mostrarlos en la tabla
function loadUsers() {
    fetch('/dashboard/users')
        .then(response => response.json())
        .then(users => {
            const tbody = document.querySelector("#userTable tbody");
            tbody.innerHTML = '';
            users.forEach(user => {
                const row = document.createElement('tr');
                row.innerHTML = `
                    <td>${user.nombre}</td>
                    <td>${user.edad}</td>
                    <td>${user.genero}</td>
                    <td>${user.peso}</td>
                    <td>${user.altura}</td>
                    <td>${user.diasActividad}</td>
                    <td>${user.tipoActividad}</td>
                    <td>${user.objetivo}</td>
                    <td>${user.telefono}</td>
                    <td>${user.reto}</td>
                    <td>${user.reto_pagado ? 'Sí' : 'No'}</td>
                    <td><img src="${user.foto_antes}" width="50" alt="Foto Antes"></td>
                    <td><img src="${user.foto_despues}" width="50" alt="Foto Después"></td>
                    <td>
                        <button onclick="openEditForm(${user.id})">Editar</button>
                        <button onclick="openPhotoForm(${user.id})">Subir Fotos</button>
                        <button onclick="deleteUser(${user.id})">Eliminar</button>
                    </td>
                `;
                tbody.appendChild(row);
            });
        });
}

// Función para abrir el formulario de edición
function openEditForm(id) {
    fetch(`/dashboard/users/${id}`)
        .then(response => response.json())
        .then(user => {
            const form = document.getElementById('editForm');
            form.nombre.value = user.nombre;
            form.edad.value = user.edad;
            form.genero.value = user.genero;
            form.peso.value = user.peso;
            form.altura.value = user.altura;
            form.diasActividad.value = user.diasActividad;
            form.tipoActividad.value = user.tipoActividad;
            form.objetivo.value = user.objetivo;
            form.telefono.value = user.telefono;
            form.reto.value = user.reto;
            form.reto_pagado.checked = user.reto_pagado;

            // Muestra el formulario de edición y guarda el ID del usuario
            form.dataset.userId = id;
            document.getElementById('editFormContainer').style.display = 'block';
        });
}

// Función para guardar los cambios de edición
document.getElementById('editForm').onsubmit = function(e) {
    e.preventDefault();
    const id = this.dataset.userId;
    const formData = new FormData(this);

    fetch(`/dashboard/users/${id}`, {
        method: 'PUT',
        body: JSON.stringify(Object.fromEntries(formData)),
        headers: {
            'Content-Type': 'application/json'
        }
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        closeEditForm();
        loadUsers();
    });
};

// Función para cerrar el formulario de edición
function closeEditForm() {
    document.getElementById('editFormContainer').style.display = 'none';
}

// Función para abrir el formulario de carga de fotos
function openPhotoForm(id) {
    const form = document.getElementById('photoForm');
    form.dataset.userId = id; // Guardar el ID del usuario en el formulario
    document.getElementById('photoFormContainer').style.display = 'block';
}

// Función para cargar las fotos
document.getElementById('photoForm').onsubmit = function(e) {
    e.preventDefault();
    const id = this.dataset.userId;
    const formData = new FormData(this);

    fetch(`/dashboard/users/${id}/uploadPhotos`, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        alert(data.message);
        closePhotoForm();
        loadUsers();
    });
};

// Función para cerrar el formulario de carga de fotos
function closePhotoForm() {
    document.getElementById('photoFormContainer').style.display = 'none';
}

// Función para eliminar usuario
function deleteUser(id) {
    if (confirm("¿Estás seguro de que quieres eliminar este usuario?")) {
        fetch(`/dashboard/users/${id}`, { method: 'DELETE' })
            .then(response => response.json())
            .then(data => {
                alert(data.message);
                loadUsers();
            });
    }
}
