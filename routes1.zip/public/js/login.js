document.getElementById('login-form').addEventListener('submit', function (event) {
    event.preventDefault(); // Evita que se recargue la página

    const formData = new FormData(this);
    const data = Object.fromEntries(formData);

    fetch('/api/users/login', { // Ruta correcta del backend
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
    })
    .then(response => response.json())
    .then(data => {
        if (data.token) {
            localStorage.setItem('token', data.token); // Guarda el token en localStorage
            console.log('Redirigiendo al dashboard...');
            window.location.href = '/dashboard.html'; // Redirige al dashboard
        } else {
            console.error('Error en el login:', data.error);
        }
    })
    .catch(error => console.error('Error en el login:', error));
});
