const express = require('express');
const router = express.Router();
const { registerUser, getUsersDashboard } = require('../controllers/userController');
const { loginUser } = require('../controllers/authController');
const dashboardController = require('../controllers/dashboardController');
const fileUpload = require('express-fileupload');

// Middleware para subir archivos
router.use(fileUpload());

// Rutas para el registro de usuario y dashboard
router.post('/register', registerUser);
router.get('/dashboard', getUsersDashboard);
router.post('/login', loginUser);

// Rutas para operaciones en el dashboard
router.get('/dashboard/users', dashboardController.getUsers);
router.put('/dashboard/users/:id', dashboardController.updateUser);
router.post('/dashboard/users/:id/photos', dashboardController.uploadPhotos);
router.delete('/dashboard/users/:id', dashboardController.deleteUser);

module.exports = router;
